Write and include a brief document in README.md describing the design choices, any challenges faced, and how they were resolved.

I choose simple design only. The challenges I faced are alligning everything together and make it complementary to eachother. I resolve this in using the validator to check errors and troubleshooting.